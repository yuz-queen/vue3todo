<script setup lang="ts">
import TodoMain from "./views/todoMain/TodoMain.vue";

</script>

<template>
  <todo-main/>
</template>

<style>

</style>
