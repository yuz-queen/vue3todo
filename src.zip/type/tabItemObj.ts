export type tabItemObj = {
    id: string,
    name: string,
    active: boolean
}