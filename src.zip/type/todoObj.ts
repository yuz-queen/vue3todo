export type todoObj = {
  idx: number;
  title: string;
  status: boolean;
};
