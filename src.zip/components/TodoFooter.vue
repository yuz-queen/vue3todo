<template>
  <div>TodoFooter</div>
</template>

<script setup lang='ts'>

</script>

<style></style>